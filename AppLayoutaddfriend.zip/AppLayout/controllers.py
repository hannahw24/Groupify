"""
This file defines actions, i.e. functions the URLs are mapped into
The @action(path) decorator exposed the function at URL:

    http://127.0.0.1:8000/{app_name}/{path}

If app_name == '_default' then simply

    http://127.0.0.1:8000/{path}

If path == 'index' it can be omitted:

    http://127.0.0.1:8000/

The path follows the bottlepy syntax.

@action.uses('generic.html')  indicates that the action uses the generic.html template
@action.uses(session)         indicates that the action uses the session
@action.uses(db)              indicates that the action uses the db
@action.uses(T)               indicates that the action uses the i18n & pluralization
@action.uses(auth.user)       indicates that the action requires a logged in user
@action.uses(auth)            indicates that the action requires the auth object

session, db, T, auth, and tempates are examples of Fixtures.
Warning: Fixtures MUST be declared with @action.uses({fixtures}) else your app will result in undefined behavior
"""

from py4web import action, request, abort, redirect, URL, Field
from yatl.helpers import A
from .common import db, session, T, cache, auth, logger, authenticated, unauthenticated
from py4web.utils.form import Form, FormStyleBulma
from py4web.utils.url_signer import URLSigner
############ Notice, new utilities! ############
import spotipy
import spotipy.util as util
from spotipy.oauth2 import SpotifyOAuth
import time
import os
import uuid
################################################

# The cache folder is located in the /py4web folder. 
# Keep this in mind when we move on from local hosting. 
caches_folder = './.spotify_caches/'
if not os.path.exists(caches_folder):
    os.makedirs(caches_folder)

def session_cache_path():
    return caches_folder + session.get('uuid')

# Ash: Permissions needed to be accepted by the user at login. There are more but these are the ones
# we use right now, so they are the only ones we ask.
scopes = "user-library-read user-read-private user-follow-read user-follow-modify user-top-read"

url_signer = URLSigner(session)

@action('index', method='GET')
@action.uses('index.html', session)
def getIndex(userID=None):
    if userID is not None:
        user_from_table = db.dbUser[getIDFromUserTable(session.get("userID"))]
        theme_colors = return_theme(user_from_table.chosen_theme)

        return dict(
            session=session, 
            editable=False,
            background_bot=theme_colors[0], 
            background_top=theme_colors[1],
            )
    else:
        return dict( 
            session=session, editable=False, 
            background_bot=None, 
            background_top=None,)

# https://github.com/plamere/spotipy/blob/master/examples/search.py
# Emulates the caching, authentication managing, and uuid assigning as 
# shown in the above git repository. It is an example of multi-person login
# with spotipy. 
# See License of code at https://github.com/plamere/spotipy/blob/master/LICENSE.md 
@action('login', method='GET')
@action.uses('login.html', session)
def userLogin():
    if not session.get('uuid'):
        # Step 1. Visitor is unknown, give random ID
        session['uuid'] = str(uuid.uuid4())
    cache_handler = spotipy.cache_handler.CacheFileHandler(cache_path=session_cache_path())
    # Magic code; takes in our client_id, secret_id, and redirect_uri and 
    # and once the user accepts the requested permissions it retrieves a token for us.
    auth_manager = spotipy.oauth2.SpotifyOAuth(scope=scopes,
                                                cache_handler=cache_handler, 
                                                show_dialog=True)
    auth_url = auth_manager.get_authorize_url()
    # In this case the auth_url is [localhost]/callback
    return redirect(auth_url)

# Step 1: When you login, Spotify goes to this
@action('callback')
@action.uses(session)
def getCallback():
    # Ash: Clear the session in case a user has logged out. If we don't do this and a user tries to login with another
    # account then they will be logged in to their first account no matter what. 
    session.clear()
    cache_handler = spotipy.cache_handler.CacheFileHandler(cache_path=session_cache_path())
    auth_manager = spotipy.oauth2.SpotifyOAuth(scope=scopes,
                                                cache_handler=cache_handler, 
                                                show_dialog=True)
    # How to get a parameter from a url.
    # https://stackoverflow.com/questions/5074803/retrieving-parameters-from-a-url 
    code = request.GET.get('code')
    error = request.GET.get('error')
    # Ash: If the user cancels their login then this handles the error by taking them back to the login page.
    if error is not None:
        print(error)
        return redirect(URL('index'))
    auth_manager.get_access_token(code)
    return redirect("getUserInfo")

# Step 2: After callback, the user goes to this function and has their info made/updated
# Places a User's info in the database and then sends them to their profile.
@action('getUserInfo')
@action.uses(db, session)
def getUserInfo():
    # Makes sure we have a user token from Spotify, else return user to login
    cache_handler = spotipy.cache_handler.CacheFileHandler(cache_path=session_cache_path())
    auth_manager = spotipy.oauth2.SpotifyOAuth(cache_handler=cache_handler)
    if not auth_manager.validate_token(cache_handler.get_cached_token()):
        return redirect('login')

    # Necessary to make a call to the API.
    spotify = spotipy.Spotify(auth_manager=auth_manager)
    # "sp.current_user()" returns: display name, email
    # url to user, id, images (profile pic), and premium status
    results = spotify.current_user()

    display_name = results["display_name"]
    userID = results["id"]
    # Sets the profile pic of the user, if no profile pic found on spotify, set it to nothing
    if (len(results["images"]) != 0):
        profile_pic = results["images"][0]["url"]
    else:
        profile_pic = ""

    # Assigns the userID to the session. This is used to verify who can edit
    # profiles. 
    session["userID"] = userID
    # Gets the URL ready for the redirect
    profileURL = "user/" + userID
    # Obtains the user entry from dbUser 
    dbUserEntry = (db(db.dbUser.userID == userID).select().as_list())
    # Finds the album covers table corresponding to the user
    squareEntries = db(db.squares.albumsOfWho == getIDFromUserTable(userID)).select().as_list()
    # This takes all the instances of the logged in user in the friends database. 	
    # This is so we can update their information.
    friendsEntries =  (db(db.dbFriends.userID == userID).select().as_list())


    # Not sure if returns as None or an empty list if user is new.
    if (dbUserEntry == None) or dbUserEntry == []:
        db.dbUser.insert(userID=userID, display_name=display_name, profile_pic=profile_pic)
        insertedID = getIDFromUserTable(userID)
    # If it is in the database, update its top tracks
    else:
        # Update all info
        db(db.dbUser.userID == userID).update(display_name=display_name)
        db(db.dbUser.userID == userID).update(profile_pic=profile_pic)
    # Updates the information in friends database so the friends NAV bar is up to date. 
    if (friendsEntries != None) and (friendsEntries != []):
        # If user profile or name has changed, update it.
        if (friendsEntries[0]["profile_pic"] != profile_pic) or \
            (friendsEntries[0]["display_name"] != display_name):
            for row in friendsEntries:
                dbRow = db(db.dbFriends.id == row["id"])
                dbRow.update(profile_pic=profile_pic)
                dbRow.update(display_name=display_name)
                
    # These are function calls that store/update the user's tops songs
    # over three time periods
    getTopTracksLen(userID, "short_term")	
    getTopTracksLen(userID, "medium_term")	
    getTopTracksLen(userID, "long_term")

    # If the album covers table is empty, we insert it here
    if (squareEntries == None) or (squareEntries == []):
        insertedID = getIDFromUserTable(userID)
        db.squares.insert(albumsOfWho=insertedID)
    return redirect(profileURL)

def getTopTracksLen(userID, term):
    # A list containing information about the User's top tracks. 
    # "term" is a period passed in to select the songs from a desired time.
    tracksList = getTopTracksFunction(term)
    topTracks = tracksList[0] # Names
    topArtists = tracksList[1] # Names
    imgList = tracksList[2] # URLs to images
    trackLinks = tracksList[3] # URLs to songs
    artistLinks = tracksList[4] # URLs to artists

    # Selects the correct user entry from the desired time period
    if term == 'short_term':
        termEntry = (db(db.shortTerm.topTracksOfWho == getIDFromUserTable(userID)).select().as_list())
    elif term == 'medium_term':
        termEntry = (db(db.mediumTerm.topTracksOfWho == getIDFromUserTable(userID)).select().as_list())
    elif term == 'long_term':
        termEntry = (db(db.longTerm.topTracksOfWho == getIDFromUserTable(userID)).select().as_list())

    # Is their desired term of top tracks populated?
    # If it isn't, then the information from tracksList will be inserted.
    if (termEntry == None) or (termEntry == []):
        insertedID = getIDFromUserTable(userID)
        if term == 'short_term':
            db.shortTerm.insert(topTracks=topTracks, topArtists=topArtists, imgList=imgList, 
                            trackLinks=trackLinks, artistLinks=artistLinks, topTracksOfWho=insertedID)
        elif term == 'medium_term':
            db.mediumTerm.insert(topTracks=topTracks, topArtists=topArtists, imgList=imgList, 
                            trackLinks=trackLinks, artistLinks=artistLinks, topTracksOfWho=insertedID)
        elif term == 'long_term':
            db.longTerm.insert(topTracks=topTracks, topArtists=topArtists, imgList=imgList, 
                            trackLinks=trackLinks, artistLinks=artistLinks, topTracksOfWho=insertedID)

    # If there are already tracks, then update the information
    else:
        insertedID = getIDFromUserTable(userID)
        # Finds the correct user entry
        if term == 'short_term':
            dbRow = db(db.shortTerm.topTracksOfWho == insertedID)
        elif term == 'medium_term':
            dbRow = db(db.mediumTerm.topTracksOfWho == insertedID)
        elif term == 'long_term':
            dbRow = db(db.longTerm.topTracksOfWho == insertedID)

        dbRow.update(topTracks=topTracks)
        dbRow.update(topArtists=topArtists)
        dbRow.update(imgList=imgList)
        dbRow.update(trackLinks=trackLinks)
        dbRow.update(artistLinks=artistLinks)
        
    return

# Profile tests (currently no difference between them)
# http://127.0.0.1:8000/AppLayout/user/1228586386           Ash's Main Account
# http://127.0.0.1:8000/AppLayout/user/wjmmbwcxcja7s2acm9clcydkb    Ash's Test Account

# Function that returns all the information needed for the user page. 
# userID that is passed into the function can be the logged in user, or 
# another user. 
@action('user/<userID>', method='GET')
@action('add_friend', method=["GET", "POST"])
@action.uses('user.html', session)
def getUserProfile(userID=None):
    # Function determines whether or not the current user can edit the profile
    print("Editable: ", editable_profile(userID))

    # If the user has not logged in, this forces them to login
    # This is an implementation decision that can change later.
    if (session.get("userID") == None) or (userID == None):
        return redirect(URL('index'))

    # Finds the entry inside dbUser of the logged in user.
    loggedInUserEntry = db(db.dbUser.userID == session.get("userID")).select().as_list()
    # Finds the entry inside dbUser of the profile the user wants to visit
    currentProfileEntry = db(db.dbUser.userID == userID).select().as_list()
    # If the profile they want to access does not exist, return userNotFound page
    if currentProfileEntry == []:
        return userNotFound(session.get("userID"))

    # Looks at the dbUser database to see what the chosen term of the top 10 songs are for
    # the profile the user wants to access
    currentChosenTerm = (db.dbUser[getIDFromUserTable(userID)]).chosen_term	
    if currentChosenTerm == '1':	
        term_str = 'last 4 weeks'	
        termList = db(db.shortTerm.topTracksOfWho == getIDFromUserTable(userID)).select().as_list()	
    elif currentChosenTerm == '2':	
        term_str = 'last 6 months'	
        termList = db(db.mediumTerm.topTracksOfWho == getIDFromUserTable(userID)).select().as_list()	
    elif currentChosenTerm == '3':	
        term_str = 'of all time'	
        termList = db(db.longTerm.topTracksOfWho == getIDFromUserTable(userID)).select().as_list()	
    else:	
        term_str = 'last 4 weeks'	
        termList = db(db.shortTerm.topTracksOfWho == getIDFromUserTable(userID)).select().as_list()

    # Obtains the album covers of the profile the user wants to vist
    squareEntries = db(db.squares.albumsOfWho == getIDFromUserTable(userID)).select().as_list()

    # A list of URLs which are used to display images of the covers
    coverList = squareEntries[0]["coverList"]
    # a list of URLs to redirect users to the albums in each box
    urlList = squareEntries[0]["urlList"]

    # Declared early for checking an error where a user hasn't listened to songs, do not remove
    topTracks = None
        
    # To see if the button "Unfollow" or "Follow" appears
    isFriend = False

    # Get the fields from the termList, but only if they have a reference in it 
    if termList != []:
        topTracks = termList[0]["topTracks"]
        topArtists = termList[0]["topArtists"]
        imgList = termList[0]["imgList"]
        trackLinks = termList[0]["trackLinks"]
        artistLinks = termList[0]["artistLinks"]

    # This handles if a user hasn't listened to any songs or has less than 10 songs listened to.
    if (topTracks == None) or len(topTracks) < 10:
        topTracks = fillerTopTracks
        topArtists = fillerTopTracks
        imgList = fillerTopTracks
        trackLinks = fillerTopTracks
        artistLinks = fillerTopTracks

    # Sets the user's profile pic
    profile_pic = ""
    if (currentProfileEntry != None) and (currentProfileEntry != []):
        # Setting profile pic variable to display on page
        profile_pic = currentProfileEntry[0]["profile_pic"]
    # Avoid the for loop errors in user.html that would occur if friendsList is None
    friendsList = []
    # The friends list shown will ALWAYS be of the user who is logged in
    userNumber = loggedInUserEntry[0]["id"]
    friendsList = db(db.dbFriends.friendToWhoID == userNumber).select(orderby=db.dbFriends.display_name).as_list()
    # To see if the button "Unfollow" or "Follow" appears
    isFriend = db((db.dbFriends.friendToWhoID == getIDFromUserTable(session.get("userID"))) & (db.dbFriends.userID == userID)).select().as_list()
    if (isFriend != []):
        isFriend=True

    # nullError
    # alreadyFriend
    # CannotAddSelf
    if request.method == "GET":
        nullError = False
        alreadyFriend = False
        CannotAddSelf = False
    else:
        loggedInUserId = session.get("userID")
        form_userID = request.params.get("userID")
        dbUserEntry = (db(db.dbUser.userID == form_userID).select().as_list())
        if dbUserEntry == []:
            nullError = True
            alreadyFriend = False
            CannotAddSelf = False

        if (checkIfFriendDuplicate(form_userID)):
            nullError = False
            alreadyFriend = True
            CannotAddSelf = False

        if (form_userID == loggedInUserId): 
            nullError = False
            alreadyFriend = False
            CannotAddSelf = True

        db.dbFriends.insert(userID=form_userID, friendToWhoID=getIDFromUserTable(loggedInUserId), 
                            profile_pic=dbUserEntry[0]["profile_pic"], display_name=dbUserEntry[0]["display_name"])


    # get the current chosen theme in the db.user, and set 5 varibles to be passed to html
    # [background_bot, background_top, friend_tile, tile_color, text_color]
    theme_colors = return_theme((db.dbUser[getIDFromUserTable(userID)]).chosen_theme)
    dbUserEntry = (db(db.dbUser.userID == userID).select().as_list())

    display_name=dbUserEntry[0]["display_name"]
    bio_status=dbUserEntry[0]["bio_status"]
    # print(bio_status)


    return dict(
        session=session, 
        editable=editable_profile(userID), 
        friendsList=friendsList, 
        topTracks=topTracks,
        term_str=term_str,
        topArtists=topArtists, 
        imgList=imgList, 
        trackLinks=trackLinks, 
        artistLinks=artistLinks, 
        profile_pic=profile_pic,

        background_bot=theme_colors[0],
        background_top=theme_colors[1],
        friend_tile=theme_colors[2],
        tile_color=theme_colors[3],
        text_color=theme_colors[4],

        userID=userID, 
        display_name=display_name,
        bio_status=bio_status,
        isFriend=isFriend, 
        url_signer=url_signer, 
        urlList=urlList, 
        coverList=coverList,
        userBio=URL("userBio", userID),

        nullError = nullError,
        alreadyFriend = alreadyFriend,
        CannotAddSelf = CannotAddSelf,
        )

# After the user clicks on an album box to edit, this function is called. 
# It displays the search bar and results of the search.
@action('user/<userID>/edit/<squareNumber>', method=["GET", "POST"])
@action.uses('search.html', session)
def editUserSquare(userID, squareNumber):
    profileURL = (URL("user", userID))
    # Probably super inefficient to set all these but 500 errors if we dont right now
    topAlbums = ""
    topArtists = ""
    imgList = ""
    trackLinks = ""
    artistLinks = ""   
    totalResults = 0
    # Because search.html extends layout.html, we must return the background colors
    # that layout.html demands.
    theme_colors = return_theme((db.dbUser[getIDFromUserTable(userID)]).chosen_theme)

    # When search.html is first seen, the request method is GET
    if request.method == "GET":
        return dict(session=session, editable=False, topAlbums=topAlbums, topArtists=topArtists,
        imgList=imgList, trackLinks=trackLinks, artistLinks=artistLinks, totalResults=totalResults, 
        url_signer=url_signer, userID=userID, inputAlbum=URL('inputAlbum'), squareNumber=squareNumber, 
        profileURL=profileURL,
        
        background_bot=theme_colors[0],
        background_top=theme_colors[1])
    # After the user searches, the method is POST
    else:
        # Getting the string the user put in the search bar
        form_SearchValue = request.params.get("Search")
        # If the string is empty, return the page with no results
        if form_SearchValue == "":
            return dict(session=session, editable=False, topAlbums=topAlbums, topArtists=topArtists,
            imgList=imgList, trackLinks=trackLinks, artistLinks=artistLinks, totalResults=totalResults, 
            url_signer=url_signer, userID=userID, inputAlbum=URL('inputAlbum'), squareNumber=squareNumber, 
            profileURL=profileURL,
            
            background_bot=theme_colors[0],
            background_top=theme_colors[1])
        # Checks to see if we have the user token to make a request to the Spotify API
        cache_handler = spotipy.cache_handler.CacheFileHandler(cache_path=session_cache_path())
        auth_manager = spotipy.oauth2.SpotifyOAuth(cache_handler=cache_handler)
        if not auth_manager.validate_token(cache_handler.get_cached_token()):
            return redirect('login')
        spotify = spotipy.Spotify(auth_manager=auth_manager)
        # Here we use the search() function is spotipy to obtain the search results. 
        # The type of results we want are albums, because we are interested in users
        # displaying their favorite albums and their cover art.
        results = spotify.search(form_SearchValue, type='album', limit=10)
        # Cautionary try/except statements in case another programmer decides to change
        # the type from 'album' to something else. If they do this and they use the 
        # results["albums"] line below, they will cause an error.
        try:
            # If the search results yielded no results, then return nothing. 
            totalResults = results["albums"]["total"]
            if (totalResults == 0):
                return dict(session=session, editable=False, topAlbums=topAlbums, topArtists=topArtists,
                imgList=imgList, trackLinks=trackLinks, artistLinks=artistLinks, totalResults=totalResults, 
                url_signer=url_signer, userID=userID, inputAlbum=URL('inputAlbum'), squareNumber=squareNumber, 
                profileURL=profileURL,
                
                background_bot=theme_colors[0],
                background_top=theme_colors[1])
            # Else begint to parse the JSON by looking at the albums
            results = results["albums"]
        except:
            print(results)
            return dict(session=session, editable=False, topAlbums=topAlbums, topArtists=topArtists,
            imgList=imgList, trackLinks=trackLinks, artistLinks=artistLinks, totalResults=totalResults, 
            url_signer=url_signer, userID=userID, inputAlbum=URL('inputAlbum'), squareNumber=squareNumber, 
            profileURL=profileURL,
                
            background_bot=theme_colors[0],
            background_top=theme_colors[1])

        # Parses through the JSON and returns a list of lists with the information we desire
        biglist = getAlbumResults(results)
        topAlbums = biglist[0]
        topArtists = biglist[1]
        imgList = biglist[2]
        trackLinks = biglist[3]
        artistLinks = biglist[4]
        # Return this information to display
        return dict(session=session, editable=False, topAlbums=topAlbums, topArtists=topArtists,
        imgList=imgList, trackLinks=trackLinks, artistLinks=artistLinks, totalResults=totalResults, 
        url_signer=url_signer, userID=userID, inputAlbum=URL('inputAlbum'), squareNumber=squareNumber, 
        profileURL=profileURL,
        
        background_bot=theme_colors[0],
        background_top=theme_colors[1])

# This function updates the logged in user's cover art squares. 
# It takes in an axios.post request and obtains the user, the square
# they are editing 
@action('inputAlbum', method="POST")
@action.uses(session)
def inputAlbum():
    # Obtains the parameters passed in to the save_album function in search.js
    userID = session.get('userID')
    squareNumber = request.params.get('squareNumber') 
    cover = request.params.get('cover')
    albumURL = request.params.get('albumURL')
    
    # Finds the entry of the user in the squares table
    dbSquareEntry = db(db.squares.albumsOfWho == getIDFromUserTable(userID))
    squareEntries = dbSquareEntry.select().as_list()

    # If the entry does not exist, return the user to the profile
    if squareEntries == []:
        return redirect(URL('user', userID))
    # Else obtain the present cover images and URLS of ALL the boxes.
    coverList = squareEntries[0]["coverList"]
    urlList = squareEntries[0]["urlList"]

    # Here we update the specific box we want to change through our knowledge of its index. 
    coverList[int(squareNumber)] = cover
    urlList[int(squareNumber)] = albumURL
    # Updates the square in the table.
    dbSquareEntry.update(coverList=coverList, urlList=urlList)

    # Returning something for user.js
    return ""

# Finds the row number of the userID inside of dbUser
def getIDFromUserTable(userID):
    insertedID = (db(db.dbUser.userID == userID).select().as_list())
    if (insertedID is not None) and (insertedID != []):
        return insertedID[0]["id"]
    return None

# When a user tries to see a profile that is not in our database, return this.
@action('userNotFound', method='GET')
@action.uses('user_not_found.html', session)
def userNotFound(userID):
    # Sets the userNotFound page's colors to the user's chosen theme.
    try:
        user_from_table = db.dbUser[getIDFromUserTable(session.get("userID"))]
        theme_colors = return_theme(user_from_table.chosen_theme)
    # If the user has no chosen theme, because they have never logged in or deleted
    # their profile, then the theme will be default.
    except:
        theme_colors = return_theme(0)
    # If the user has never logged in or deleted their profile, the user not found page 
    # will redirect them to the login page.
    loggedInUserEntry = db(db.dbUser.userID == session.get("userID")).select().as_list()
    if (loggedInUserEntry == []):
        return redirect(URL('index'))
    return dict(session=session, editable=False, userID=userID, url_signer=url_signer, 
                background_bot=theme_colors[0], 
                background_top=theme_colors[1])

# Returns whether the user can edit a profile
@action.uses(session)
def editable_profile(userID):
    profileOwner = False
    if userID == None:
        return profileOwner
    profile_info = session.get("userID")
    # Checking if the session already has a token stored
    if profile_info != userID:
        return profileOwner

    profileOwner = True
    return profileOwner

@action('user/<userID>/<theme_id:int>')
@action.uses(db, session)
def update_theme(userID=None, theme_id=None):
    assert theme_id is not None
    assert userID is not None
    print(theme_id)
    print(userID)
    user_data = db.dbUser[getIDFromUserTable(userID)]
    db(db.user_data.id == getIDFromUserTable(userID).update(chosen_theme=theme_id))

    profileURL = "user/" + userID
    redirect(profileURL)
    return dict(session=session)

# UNUSED
# Returns the most recent 20 liked songs
@action('getLikedTracks')
def getLikedTracks():
    cache_handler = spotipy.cache_handler.CacheFileHandler(cache_path=session_cache_path())
    auth_manager = spotipy.oauth2.SpotifyOAuth(cache_handler=cache_handler)
    if not auth_manager.validate_token(cache_handler.get_cached_token()):
        return redirect('login')
    spotify = spotipy.Spotify(auth_manager=auth_manager)
    results = spotify.current_user_saved_tracks()
    #Taken from the quick start of Spotipy authorization flow
    #https://spotipy.readthedocs.io/en/2.18.0/#authorization-code-flow
    LikedSongsString= ""
    for idx, item in enumerate(results['items']):
        track = item['track']
        LikedSongsString = LikedSongsString + str((idx, track['artists'][0]['name'], " – ", track['name'])) + "<br>"
    return LikedSongsString

# UNUSED, but perhaps will be soon
# Gets the information of songs from a search result
def getSearchResults(results):
    TopSongsString= ""
    TopSongsList = []
    TopArtistsList = []
    ImgLinkList = []
    TLinkList = []
    ALinkList = []
    BigList = []
    for idx, item in enumerate(results['items']):
        # Get items from correct place in given Spotipy dictionary
        track = item['name']
        trackInfo = item['album']['artists'][0]['name']
        icon = item['album']['images'][2]['url']
        trLink = item['external_urls']['spotify']
        artLink = item['album']['artists'][0]['external_urls']['spotify']
        TopSongsList.append(track)
        TopSongsString = TopSongsString + str(track) + "<br>"
        TopArtistsList.append(trackInfo)
        ImgLinkList.append(icon)
        TLinkList.append(trLink)
        ALinkList.append(artLink)
    # Avoid empty lists
    if TopSongsList == []:
        TopSongsList = ""
    if TopArtistsList == []:
        TopArtistsList= ""
    if ImgLinkList == []:
        ImgLinkList = ""
    if TLinkList == []:
        TLinkList = ""
    if TLinkList == []:
        ALinkList = ""
    # Add all to list to be returned
    BigList.append(TopSongsList)
    BigList.append(TopArtistsList)
    BigList.append(ImgLinkList)
    BigList.append(TLinkList)
    BigList.append(ALinkList)
    # Returned to the user profile
    return BigList

# A slightly different version for specifically albums, higher res images
def getAlbumResults(results):
    TopSongsString= ""
    TopSongsList = []
    TopArtistsList = []
    ImgLinkList = []
    TLinkList = []
    ALinkList = []
    BigList = []
    for idx, item in enumerate(results['items']):
        # Get items from correct place in given Spotipy dictionary
        track = item['name']
        trackInfo = item['artists'][0]['name']
        icon = item['images'][0]['url']
        trLink = item['external_urls']['spotify']
        artLink = item['artists'][0]['external_urls']['spotify']
        TopSongsList.append(track)
        TopSongsString = TopSongsString + str(track) + "<br>"
        TopArtistsList.append(trackInfo)
        ImgLinkList.append(icon)
        TLinkList.append(trLink)
        ALinkList.append(artLink)
    # Avoid empty lists
    if TopSongsList == []:
        TopSongsList = ""
    if TopArtistsList == []:
        TopArtistsList= ""
    if ImgLinkList == []:
        ImgLinkList = ""
    if TLinkList == []:
        TLinkList = ""
    if TLinkList == []:
        ALinkList = ""
    # Add all to list to be returned
    BigList.append(TopSongsList)
    BigList.append(TopArtistsList)
    BigList.append(ImgLinkList)
    BigList.append(TLinkList)
    BigList.append(ALinkList)
    # Returned to the user profile
    return BigList  

def getTopTracksFunction(term):
    cache_handler = spotipy.cache_handler.CacheFileHandler(cache_path=session_cache_path())
    auth_manager = spotipy.oauth2.SpotifyOAuth(cache_handler=cache_handler)
    if not auth_manager.validate_token(cache_handler.get_cached_token()):
        return redirect('login')
    spotify = spotipy.Spotify(auth_manager=auth_manager)

    # long_term = all time
    # medium_term = 6 months
    # short_term = 4 weeks
    results = spotify.current_user_top_tracks(limit=10, offset=0, time_range=term)    #Taken from the quick start of Spotipy authorization flow
    #https://spotipy.readthedocs.io/en/2.18.0/#authorization-code-flow
    # Initialize Lists for each field
    TopSongsString= ""
    TopSongsList = []
    TopArtistsList = []
    ImgLinkList = []
    TLinkList = []
    ALinkList = []
    BigList = []
    for idx, item in enumerate(results['items']):
        # Get items from correct place in given Spotipy dictionary
        track = item['name']
        trackInfo = item['album']['artists'][0]['name']
        icon = item['album']['images'][2]['url']
        trLink = item['external_urls']['spotify']
        artLink = item['album']['artists'][0]['external_urls']['spotify']
        TopSongsList.append(track)
        TopSongsString = TopSongsString + str(track) + "<br>"
        TopArtistsList.append(trackInfo)
        ImgLinkList.append(icon)
        TLinkList.append(trLink)
        ALinkList.append(artLink)
    # Avoid empty lists
    if TopSongsList == []:
        TopSongsList = ""
    if TopArtistsList == []:
        TopArtistsList= ""
    if ImgLinkList == []:
        ImgLinkList = ""
    if TLinkList == []:
        TLinkList = ""
    if TLinkList == []:
        ALinkList = ""
    # Add all to list to be returned
    BigList.append(TopSongsList)
    BigList.append(TopArtistsList)
    BigList.append(ImgLinkList)
    BigList.append(TLinkList)
    BigList.append(ALinkList)
    # Returned to the user profile
    return BigList

@action('groupSession/<userID>')
@action.uses(db, auth, 'groupSession.html', session)
def groupSession(userID=None):
    # Ash: set editable to False for now, not sure if setting the theme
    #      on the groupSession page will change it for everyone
    profileURL = "http://127.0.0.1:8000"+(URL("user", userID))
    currentProfileEntry = db(db.dbUser.userID == userID).select().as_list()
    profile_pic = ""
    if (currentProfileEntry != None) and (currentProfileEntry != []):
       # Setting the top tracks and profile pic variables
       profile_pic = currentProfileEntry[0]["profile_pic"]
    if userID is not None:
        try:
            user_from_table = db.dbUser[getIDFromUserTable(session.get("userID"))]
            theme_colors = return_theme(user_from_table.chosen_theme)
        except:
            theme_colors = return_theme(0)
        return dict( 
            session=session, editable=False,
            background_bot=theme_colors[0],background_top=theme_colors[1],
            profile_pic=profile_pic, profileURL = profileURL,
            )
    else:
        return dict( 
            session=session, editable=False, 
            background_bot=None, background_top=None,
            profile_pic=profile_pic, profileURL = profileURL,
            )

@action('settings/<userID>')
@action.uses(db, auth, 'settings.html', session)
def getSettings(userID=None):
    profileURL = "http://127.0.0.1:8000"+(URL("user", userID))
    currentProfileEntry = db(db.dbUser.userID == userID).select().as_list()
    profile_pic = ""
    if (currentProfileEntry != None) and (currentProfileEntry != []):
       # Setting the top tracks and profile pic variables
       profile_pic = currentProfileEntry[0]["profile_pic"]
    if userID is not None:
        user_from_table = db.dbUser[getIDFromUserTable(session.get("userID"))]
        theme_colors = return_theme(user_from_table.chosen_theme)
        return dict( 
            session=session, 
            editable=False, 
            userID=userID, 
            url_signer=url_signer,
            background_bot=theme_colors[0],
            background_top=theme_colors[1],
            profile_pic=profile_pic, 
            profileURL = profileURL
            )
    else:
        return dict( 
            session=session, 
            editable=False, 
            userID=userID, 
            url_signer=url_signer,
            background_bot=None, 
            background_top=None,
            profile_pic=profile_pic, 
            profileURL=profileURL
        )

@action('deleteProfile/<userID>', method=['GET'])
@action.uses(session, db)
def delete_profile(userID=None):
    assert userID is not None
    db(db.dbUser.userID == userID).delete()
    db(db.dbFriends.userID == userID).delete()
    os.remove(session_cache_path())
    session.clear()
    redirect(URL('index'))

# @action('add_friend', method=["GET", "POST"])
# @action.uses(db, auth, 'user.html', session)
# def addFriend():
#     # [nullError= , alreadyFriend= , CannotAddSelf= ]
#     if request.method == "GET":
#         return [False, False, False]
#     else:
#         loggedInUserId = session.get("userID")
#         form_userID = request.params.get("userID")
#         dbUserEntry = (db(db.dbUser.userID == form_userID).select().as_list())
#         if dbUserEntry == []:
#             return [True, False, False]

#         if (checkIfFriendDuplicate(form_userID)):
#             return [False, True, False]

#         if (form_userID == loggedInUserId): 
#             return [False, False, True]

#         db.dbFriends.insert(userID=form_userID, friendToWhoID=getIDFromUserTable(loggedInUserId), 
#                             profile_pic=dbUserEntry[0]["profile_pic"], display_name=dbUserEntry[0]["display_name"])

#         # return redirect(URL('user', session.get("userID")))

@action('addFriendFromProfile/<userID>', method=["GET"])
@action.uses(db, session)
def addFriendFromProfile(userID=None):
    loggedInUserId = session.get("userID")
    if (loggedInUserId == None) or (loggedInUserId == ""):
        return redirect(URL('index'))
    dbUserEntry = (db(db.dbUser.userID == userID).select().as_list())
    if dbUserEntry == []:
        return redirect(URL('user', userID))
    if (checkIfFriendDuplicate(userID)):
        return redirect(URL('user', userID))
    if (userID == loggedInUserId):
        return redirect(URL('user', userID))
    db.dbFriends.insert(userID=userID, friendToWhoID=getIDFromUserTable(loggedInUserId), 
                            profile_pic=dbUserEntry[0]["profile_pic"], display_name=dbUserEntry[0]["display_name"])
    return redirect(URL('user', userID))


# Retrieves the bio of the user, used in user.js to display the bio
@action('userBio/<userID>', method=["GET"])
@action.uses(session)
def getUserBio(userID=None):
    currentProfileEntry = db(db.dbUser.userID == userID).select().as_list()
    print("currentProfileEntry[0][bio_status]: ", currentProfileEntry[0]["bio_status"])
    return dict(userBio=currentProfileEntry[0]["bio_status"])

# Makes a request to user.js for the content in the text area after a user hits the save button
# Then updates the bio in the database
# ASH: WARNING -- MAY BE UNSAFE/EDITABLE BY OTHERS -- NEEDS TESTING
@action('userBio/<userID>', method=["POST"])
@action.uses(session)
def postUserBio(userID=None):
    dbBioEntry = db(db.dbUser.userID == userID)
    content = request.params.get('content')
    dbBioEntry.update(bio_status=content)
    return dict(content=content)

@action('unfollowProfile/<userID>', method=['GET'])
@action.uses(session, db)
def delete_contact(userID=None):
    person = db((db.dbFriends.userID == userID) & (db.dbFriends.friendToWhoID == getIDFromUserTable(session.get("userID")))).select().as_list()
    if person is None or person == []:
        # Nothing to edit.  This should happen only if you tamper manually with the URL.
        redirect(URL('user', userID))
    else:
        person = person[0]
        friendToWhoID = person["friendToWhoID"]
        if friendToWhoID == getIDFromUserTable(session.get("userID")):
            db(db.dbFriends.id == person["id"]).delete()
        redirect(URL('user', userID))

# change the db.user's perfered theme
@action('user/<userID>/theme/<theme_id:int>')
@action.uses(db, session)
def update_db_theme(userID=None, theme_id=None):
    assert theme_id is not None
    assert userID is not None
    # print(theme_id)
    # print(userID)
    user_data = db.dbUser[getIDFromUserTable(userID)]
    db(db.dbUser.id == getIDFromUserTable(userID)).update(chosen_theme=theme_id)

    redirect(URL('user/'+userID))
    dict(session=session)

# returns the 4 color values for db.user's selected mode
def return_theme(chosen_theme=None):
    # assert chosen_theme is not None

    # will return an array of strings representing the color hex 
    # values of each theme in a format reflecting the following 
    # [background_bot, background_top, friend_tile, tile_color, text_color]

    # countryTheme brown, yellow, soft brown, soft yellow, white
    if chosen_theme == "2": 
        return ['#420d09', '#f8e473', '#A07E54', '#FFFDD6', '#FFFFFF']
    # rapTheme black, red, soft red, metal gray, white
    if chosen_theme == "3": 
        return ['#191414', '#800000', '#993333', '#919191', '#FFFFFF']
    # popTheme pink, blue, pink, white, black
    if chosen_theme == "4": 
        return ['#ffaff6', '#0080fe', '#ffaff6', '#FFFFFF', '#221B1B']
    # rnbTheme dark purple, light purple, soft purple, soft gray, white
    if chosen_theme == "5": 
        return ['#12006e', '#942ec8', '#8961d8', '#d9dddc', '#FFFFFF']
    # lofiTheme blue, mint, soft gray, soft purple, black
    if chosen_theme == "6": 
        return ['#89cfef', '#d0f0c0', '#F5F5F5', '#E5DAFB', '#221B1B']
    # metalTheme black, gray, black, gray, white
    if chosen_theme =="7":
        return ['#191414', '#B3B3B3', '#191414', '#B3B3B3', "#FFFFFF"]
    # defaultTheme black, green, green, soft gray, black
    else: 
        return ['#191414', '#4FE383', '#4FE383', '#f0f0f0', '#221B1B']

# change the db.user's perfered top 10 term	
@action('user/<userID>/top10len/<term_id:int>')	
@action.uses(db, session)	
def update_term_len(userID=None, term_id=None):	
    assert term_id is not None	
    assert userID is not None	
    user_data = db.dbUser[getIDFromUserTable(userID)]	
    db(db.dbUser.id == getIDFromUserTable(userID)).update(chosen_term=term_id)	
    redirect(URL('user/'+userID))	
    dict(session=session)	


# Taken from the spotipy examples page referenced above.
@action('sign_out')
@action.uses(session)
def sign_out():
    try:
        # Remove the CACHE file (.cache-test) so that a new user can authorize.
        os.remove(session_cache_path())
        session.clear()
    except OSError as e:
        print ("Error: %s - %s." % (e.filename, e.strerror))
    return redirect(URL('index'))

def checkIfFriendDuplicate(inputID):
    friendsEntries = (db(db.dbFriends.userID == inputID).select().as_list())
    friendtowhoID = getIDFromUserTable(session.get("userID"))
    for entry in friendsEntries:
        if (entry["friendToWhoID"] == friendtowhoID):
            return True
    return False

fillerTopTracks = ["Listen to more songs to see results", "Listen to more songs to see results",  
"Listen to more songs to see results",  "Listen to more songs to see results", "Listen to more songs to see results", 
 "Listen to more songs to see results",  "Listen to more songs to see results",  "Listen to more songs to see results", 
  "Listen to more songs to see results",  "Listen to more songs to see results",  "Listen to more songs to see results", ]
